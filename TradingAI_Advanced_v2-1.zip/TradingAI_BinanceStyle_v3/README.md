# Trading AI v3
Binance-style demo terminal with live public Binance Spot USDT market discovery, searchable coins, live 24h prices, demo BUY/SELL, virtual $10,000, order history, P&L, win rate, and AI signal cards.

The current AI is an educational heuristic, not a validated predictive model. No real orders are placed and no API secret is stored in the APK.
