# Trading AI v4 — Binance-style mobile demo terminal

This release is a visual and functional upgrade focused on a Binance-like mobile trading experience.

Included:
- Binance public Spot USDT pair discovery (dynamic list)
- Live 24h ticker prices
- Searchable markets
- Candlestick chart from Binance public klines
- Timeframe selector: 1m, 5m, 15m, 1h, 4h, 1d
- Public order book
- AI Terminal with signal / confidence / risk / indicator-style breakdown
- Demo BUY / SELL
- $10,000 virtual account
- Demo P&L, wins, losses, win rate, order history
- No real order execution

Important:
The AI signal in this APK is an educational heuristic, not a validated predictive model. It should not be represented as guaranteed profitable.

Next production stage:
- WebSocket streams for continuous live candles/ticker/order-book updates
- Real indicator calculations over historical candles
- Backtesting + walk-forward validation
- Server-side ML/LLM ensemble
- Secure authenticated account-history connector
- Forex/XAUUSD provider
- Push notifications and configurable signal rules

Never embed an exchange secret/API key in the APK. Use secure server-side storage and least-privilege permissions for any authenticated integration.
