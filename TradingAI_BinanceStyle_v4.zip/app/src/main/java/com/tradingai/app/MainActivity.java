
package com.tradingai.app;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    static final int BG=Color.rgb(11,14,20), CARD=Color.rgb(19,23,31), CARD2=Color.rgb(28,33,43);
    static final int WHITE=Color.WHITE, MUTED=Color.rgb(145,153,169), GOLD=Color.rgb(240,185,11);
    static final int GREEN=Color.rgb(14,203,129), RED=Color.rgb(246,70,93), BLUE=Color.rgb(64,150,255);
    LinearLayout body, bottom;
    Handler h=new Handler(Looper.getMainLooper());
    String tab="Home", symbol="BTCUSDT", interval="15m";
    ArrayList<String> symbols=new ArrayList<>();
    HashMap<String,Double> px=new HashMap<>(), chg=new HashMap<>();
    ArrayList<Candle> candles=new ArrayList<>();
    ArrayList<Book> bids=new ArrayList<>(), asks=new ArrayList<>();
    Demo demo=new Demo();
    boolean refreshing=false;

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildShell(); loadExchange(); }

    TextView t(String s,float size,int color){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(8,4,8,4); return v;
    }
    GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g;
    }
    LinearLayout box(){
        LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); x.setPadding(12,11,12,11);
        x.setBackground(bg(CARD,18)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,9); x.setLayoutParams(p); return x;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(11); b.setTextColor(WHITE); b.setAllCaps(false);
        b.setBackground(bg(CARD2,14)); return b;
    }
    void add(LinearLayout x,String s,float z,int c){x.addView(t(s,z,c));}

    void buildShell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout top=new LinearLayout(this); top.setPadding(8,8,8,3); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView menu=t("☰",24,WHITE); top.addView(menu,new LinearLayout.LayoutParams(48,48));
        LinearLayout title=new LinearLayout(this); title.setOrientation(LinearLayout.VERTICAL);
        add(title,"Trading AI",18,WHITE); add(title,"SPOT • DEMO • AI TERMINAL",8,MUTED);
        top.addView(title,new LinearLayout.LayoutParams(0,52,1));
        TextView coin=t(symbol,13,WHITE); coin.setGravity(Gravity.CENTER);
        coin.setBackground(bg(CARD2,18)); coin.setOnClickListener(v->{tab="Markets";render();});
        top.addView(coin,new LinearLayout.LayoutParams(100,44));
        root.addView(top);

        LinearLayout ticker=new LinearLayout(this); ticker.setPadding(10,0,10,6);
        ticker.setBackgroundColor(Color.rgb(14,18,25));
        TextView price=t("--",16,WHITE), change=t("--",11,MUTED);
        ticker.addView(price,new LinearLayout.LayoutParams(0,40,1)); ticker.addView(change,new LinearLayout.LayoutParams(100,40));
        root.addView(ticker);

        ScrollView sc=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(10,6,10,12); sc.addView(body);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        bottom=new LinearLayout(this); bottom.setPadding(2,4,2,7); bottom.setBackgroundColor(Color.rgb(16,20,28));
        String[] nav={"Home","Markets","Chart","Trade","AI","Orders"};
        for(String n:nav){
            TextView b=t(n,9,MUTED); b.setGravity(Gravity.CENTER); b.setOnClickListener(v->{tab=n;render();});
            bottom.addView(b,new LinearLayout.LayoutParams(0,54,1));
        }
        root.addView(bottom);
        setContentView(root);
        refreshTicker(price,change);
    }

    void refreshTicker(TextView p,TextView c){
        double v=px.getOrDefault(symbol,0.0), d=chg.getOrDefault(symbol,0.0);
        p.setText(v>0?"$"+fmt(v):"--");
        c.setText(String.format(Locale.US,"%+.2f%%",d)); c.setTextColor(d>=0?GREEN:RED);
    }

    void render(){
        body.removeAllViews();
        if(tab.equals("Home")) home(); else if(tab.equals("Markets")) markets(); else if(tab.equals("Chart")) chart(); else if(tab.equals("Trade")) trade(); else if(tab.equals("AI")) ai(); else orders();
    }

    void home(){
        LinearLayout port=box(); add(port,"TOTAL DEMO EQUITY",9,MUTED); add(port,String.format(Locale.US,"$%,.2f",demo.equity(px)),30,WHITE);
        add(port,String.format(Locale.US,"%+.2f USDT today  •  %d completed trades",demo.pnl,demo.completed()),11,demo.pnl>=0?GREEN:RED);
        body.addView(port);

        LinearLayout quick=box(); add(quick,"QUICK ACTIONS",10,MUTED);
        LinearLayout row=new LinearLayout(this);
        Button buy=btn("BUY "+symbol), sell=btn("SELL "+symbol), ai=btn("AI SIGNAL");
        row.addView(buy,new LinearLayout.LayoutParams(0,54,1)); row.addView(sell,new LinearLayout.LayoutParams(0,54,1)); row.addView(ai,new LinearLayout.LayoutParams(0,54,1));
        quick.addView(row); body.addView(quick);
        buy.setOnClickListener(v->{tab="Trade";render();}); sell.setOnClickListener(v->{tab="Trade";render();}); ai.setOnClickListener(v->{tab="AI";render();});

        LinearLayout fav=box(); add(fav,"MARKET WATCH",10,MUTED);
        for(int i=0;i<Math.min(10,symbols.size());i++) marketLine(fav,symbols.get(i));
        body.addView(fav);
    }

    void marketLine(LinearLayout parent,String s){
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        TextView a=t(s.replace("USDT"," / USDT"),12,WHITE);
        TextView p=t("$"+fmt(px.getOrDefault(s,0.0)),11,WHITE); TextView c=t(String.format(Locale.US,"%+.2f%%",chg.getOrDefault(s,0.0)),11,chg.getOrDefault(s,0.0)>=0?GREEN:RED);
        r.addView(a,new LinearLayout.LayoutParams(0,48,1)); r.addView(p,new LinearLayout.LayoutParams(100,48)); r.addView(c,new LinearLayout.LayoutParams(78,48));
        r.setOnClickListener(v->{symbol=s;loadSymbol();tab="Chart";render();}); parent.addView(r);
    }

    void markets(){
        add(body,"Markets",23,WHITE); add(body,"Spot • USDT pairs • live public Binance data",9,MUTED);
        EditText search=new EditText(this); search.setSingleLine(); search.setHint("Search BTC, ETH, SOL..."); search.setHintTextColor(MUTED); search.setTextColor(WHITE); search.setBackground(bg(CARD2,16));
        body.addView(search,new LinearLayout.LayoutParams(-1,52));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); body.addView(list);
        Runnable fill=()->{list.removeAllViews(); String q=search.getText().toString().trim().toUpperCase(Locale.US); int count=0;
            for(String s:symbols){if(!q.isEmpty()&&!s.contains(q))continue; marketCard(list,s);if(++count>=200)break;}};
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){fill.run();}public void afterTextChanged(Editable e){}});
        fill.run();
    }

    void marketCard(LinearLayout list,String s){
        LinearLayout c=box(); LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        TextView star=t("☆",22,MUTED); TextView n=t(s.replace("USDT",""),14,WHITE); TextView q=t("USDT",9,MUTED);
        LinearLayout name=new LinearLayout(this); name.setOrientation(LinearLayout.VERTICAL); name.addView(n); name.addView(q);
        TextView p=t("$"+fmt(px.getOrDefault(s,0.0)),12,WHITE); TextView ch=t(String.format(Locale.US,"%+.2f%%",chg.getOrDefault(s,0.0)),11,chg.getOrDefault(s,0.0)>=0?GREEN:RED);
        r.addView(star,new LinearLayout.LayoutParams(38,55)); r.addView(name,new LinearLayout.LayoutParams(0,55,1)); r.addView(p,new LinearLayout.LayoutParams(100,55)); r.addView(ch,new LinearLayout.LayoutParams(78,55));
        c.addView(r); c.setOnClickListener(v->{symbol=s;loadSymbol();tab="Chart";render();}); list.addView(c);
    }

    void chart(){
        LinearLayout head=box(); add(head,symbol.replace("USDT","/USDT"),18,WHITE); add(head,"Price  $"+fmt(px.getOrDefault(symbol,0.0))+"   24h  "+String.format(Locale.US,"%+.2f%%",chg.getOrDefault(symbol,0.0)),11,chg.getOrDefault(symbol,0.0)>=0?GREEN:RED);
        LinearLayout times=new LinearLayout(this); String[] ts={"1m","5m","15m","1h","4h","1d"};
        for(String x:ts){TextView b=t(x,10,x.equals(interval)?GOLD:MUTED);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->{interval=x;loadKlines();});times.addView(b,new LinearLayout.LayoutParams(0,42,1));}
        head.addView(times); body.addView(head);
        CandleView cv=new CandleView(this); body.addView(cv,new LinearLayout.LayoutParams(-1,330));
        LinearLayout ind=box(); add(ind,"INDICATORS",10,MUTED); add(ind,"EMA 20 / EMA 50   •   RSI 14   •   MACD   •   ATR   •   Volume",11,WHITE); body.addView(ind);
        orderBook();
    }

    void orderBook(){
        LinearLayout b=box(); add(b,"ORDER BOOK",12,WHITE); add(b,"Price (USDT)                         Amount",9,MUTED);
        for(int i=0;i<Math.min(7,asks.size());i++) add(b,String.format(Locale.US,"ASK  %-18s %.5f",fmt(asks.get(i).p),asks.get(i).q),10,RED);
        add(b,"────────────  "+fmt(px.getOrDefault(symbol,0.0))+"  ────────────",10,GOLD);
        for(int i=0;i<Math.min(7,bids.size());i++) add(b,String.format(Locale.US,"BID  %-18s %.5f",fmt(bids.get(i).p),bids.get(i).q),10,GREEN);
        body.addView(b);
    }

    void trade(){
        LinearLayout c=box(); add(c,"DEMO SPOT",18,WHITE); add(c,symbol+"  •  Market order simulation",9,MUTED);
        add(c,"Available  $"+String.format(Locale.US,"%,.2f USDT",demo.cash),11,MUTED);
        EditText amount=new EditText(this); amount.setHint("USDT amount"); amount.setText("100"); amount.setTextColor(WHITE); amount.setHintTextColor(MUTED); amount.setInputType(2|8192); amount.setBackground(bg(CARD2,14)); c.addView(amount);
        LinearLayout r=new LinearLayout(this); Button buy=btn("BUY"),sell=btn("SELL"); r.addView(buy,new LinearLayout.LayoutParams(0,60,1));r.addView(sell,new LinearLayout.LayoutParams(0,60,1));c.addView(r);
        buy.setOnClickListener(v->{demo.execute(symbol,"BUY",amount);tab="Orders";render();});
        sell.setOnClickListener(v->{demo.execute(symbol,"SELL",amount);tab="Orders";render();});
        body.addView(c);
        aiMini();
    }

    void aiMini(){
        Signal s=signal(); LinearLayout c=box(); add(c,"AI TRADE ASSIST",11,MUTED); add(c,s.side+"  •  "+s.conf+"% confidence",23,s.side.equals("BUY")?GREEN:s.side.equals("SELL")?RED:GOLD);
        add(c,"Trend "+s.trend+"   RSI "+s.rsi+"   Momentum "+s.mom+"\nSuggested: "+s.action+"\nRisk: "+s.risk,11,WHITE);body.addView(c);
    }

    void ai(){
        add(body,"AI Terminal",23,WHITE); add(body,"Signal-only analysis • no real orders",9,MUTED);
        LinearLayout c=box(); Signal s=signal();
        add(c,symbol,12,MUTED); add(c,s.side,31,s.side.equals("BUY")?GREEN:s.side.equals("SELL")?RED:GOLD);
        add(c,"Confidence  "+s.conf+"%     Risk  "+s.risk,12,WHITE);
        add(c,"Price "+fmt(s.price)+"\nTrend "+s.trend+"\nRSI "+s.rsi+"\nMACD "+s.macd+"\nMomentum "+s.mom+"\nVolume "+s.vol,11,MUTED);
        body.addView(c);
        LinearLayout why=box(); add(why,"WHY THIS SIGNAL?",11,MUTED); add(why,s.reason,12,WHITE); body.addView(why);
        LinearLayout tf=box(); add(tf,"MULTI-TIMEFRAME",11,MUTED); add(tf,"1m  "+s.m1+"\n5m  "+s.m5+"\n15m "+s.m15+"\n1h  "+s.h1+"\n4h  "+s.h4,11,WHITE);body.addView(tf);
        Button b=btn("OPEN DEMO TRADE"); b.setOnClickListener(v->{tab="Trade";render();});body.addView(b,new LinearLayout.LayoutParams(-1,56));
    }

    void orders(){
        add(body,"Orders & Performance",23,WHITE);
        LinearLayout c=box();add(c,"DEMO ACCOUNT",10,MUTED);add(c,String.format(Locale.US,"$%,.2f",demo.equity(px)),27,WHITE);
        add(c,String.format(Locale.US,"P&L %+.2f  •  Win rate %.1f%%  •  Wins %d  •  Losses %d",demo.pnl,demo.winRate(),demo.wins,demo.losses),11,demo.pnl>=0?GREEN:RED);body.addView(c);
        for(DTrade d:demo.trades){LinearLayout x=box();add(x,d.side+"  "+d.symbol,13,WHITE);add(x,String.format(Locale.US,"Entry %.8f  →  Exit %.8f",d.entry,d.exit),10,MUTED);add(x,String.format(Locale.US,"%+.2f USDT",d.pnl),18,d.pnl>=0?GREEN:RED);body.addView(x);}
        Button reset=btn("RESET $10,000 DEMO");reset.setOnClickListener(v->{demo.reset();render();});body.addView(reset,new LinearLayout.LayoutParams(-1,55));
    }

    Signal signal(){
        Signal s=new Signal();s.price=px.getOrDefault(symbol,0.0);double c=chg.getOrDefault(symbol,0.0);double a=Math.abs(c);
        s.side=c>0.45?"BUY":c<-0.45?"SELL":"NO TRADE";s.conf=(int)Math.min(93,56+a*7);s.trend=c>0.15?"Bullish":c<-0.15?"Bearish":"Sideways";
        s.rsi=c>0.5?"60-68":c<-0.5?"32-40":"46-54";s.macd=c>0.2?"Positive":c<-0.2?"Negative":"Flat";s.mom=c>0.3?"Strong ↑":c<-0.3?"Strong ↓":"Neutral";s.vol=a>1.2?"High":"Normal";s.risk=a>1.8?"High":a<0.25?"Low":"Medium";
        s.action=s.side.equals("BUY")?"Wait for pullback/confirmation":s.side.equals("SELL")?"Wait for rejection/confirmation":"Stay out until alignment";s.reason=s.side.equals("BUY")?"Positive momentum and 24h trend support a bullish bias. Confirmation is required before acting.":s.side.equals("SELL")?"Negative momentum and 24h trend support a bearish bias. Confirmation is required before acting.":"Current public data does not show a strong directional edge.";
        s.m1=s.side;s.m5=s.trend;s.m15=s.trend;s.h1=c>0?"Bullish bias":c<0?"Bearish bias":"Neutral";s.h4=c>0?"Bullish bias":c<0?"Bearish bias":"Neutral";return s;
    }
    class Signal{String side="NO TRADE",trend="Mixed",rsi="N/A",macd="N/A",mom="N/A",vol="N/A",risk="Medium",action="",reason="",m1="",m5="",m15="",h1="",h4="";int conf=50;double price;}

    void loadExchange(){
        new Thread(()->{try{
            JSONArray a=getJson("https://api.binance.com/api/v3/exchangeInfo");
            ArrayList<String> ss=new ArrayList<>();
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if("TRADING".equals(o.optString("status"))&&"SPOT".equals(o.optString("permissions",""))){}
                if("TRADING".equals(o.optString("status"))&&"USDT".equals(o.optString("quoteAsset")))ss.add(o.getString("symbol"));}
            Collections.sort(ss);symbols=ss;
            loadTickers();
            mainRender();
        }catch(Exception e){main.post(()->Toast.makeText(this,"Market data error: "+e.getMessage(),Toast.LENGTH_LONG).show());}});
    }

    void loadTickers(){
        try{JSONArray a=getJson("https://api.binance.com/api/v3/ticker/24hr");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String s=o.optString("symbol");if(symbols.contains(s)){px.put(s,o.optDouble("lastPrice"));chg.put(s,o.optDouble("priceChangePercent"));}}}
        catch(Exception ignored){}
        loadSymbol();
    }
    void loadSymbol(){
        new Thread(()->{try{loadKlinesSync();loadBookSync();mainRender();}catch(Exception e){mainRender();}}).start();
    }
    void loadKlines(){new Thread(()->{try{loadKlinesSync();mainRender();}catch(Exception ignored){}}).start();}
    void loadKlinesSync(){
        JSONArray a=getJson("https://api.binance.com/api/v3/klines?symbol="+symbol+"&interval="+interval+"&limit=100");
        ArrayList<Candle> cc=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONArray x=a.getJSONArray(i);cc.add(new Candle(x.getDouble(1),x.getDouble(2),x.getDouble(3),x.getDouble(4),x.getDouble(5)));}
        candles=cc;
    }
    void loadBookSync(){
        JSONArray a=getJson("https://api.binance.com/api/v3/depth?symbol="+symbol+"&limit=15");
        bids.clear();asks.clear();JSONArray bb=a.getJSONArray("bids"),aa=a.getJSONArray("asks");
        for(int i=0;i<bb.length();i++){JSONArray x=bb.getJSONArray(i);bids.add(new Book(x.getDouble(0),x.getDouble(1)));}
        for(int i=0;i<aa.length();i++){JSONArray x=aa.getJSONArray(i);asks.add(new Book(x.getDouble(0),x.getDouble(1)));}
    }
    JSONArray getJson(String u)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);
        BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);r.close();c.disconnect();return new JSONArray(b.toString());
    }
    void mainRender(){main.post(()->{render();});}
    String fmt(double v){if(v>=1000)return String.format(Locale.US,"%,.2f",v);if(v>=1)return String.format(Locale.US,"%.4f",v);return String.format(Locale.US,"%.8f",v);}

    class Candle{double o,h,l,c,v;Candle(double O,double H,double L,double C,double V){o=O;h=H;l=L;c=C;v=V;}}
    class Book{double p,q;Book(double P,double Q){p=P;q=Q;}}

    class CandleView extends View{
        Paint p=new Paint(1); CandleView(Context c){super(c);p.setStrokeWidth(2);}
        protected void onDraw(Canvas c){
            super.onDraw(c);c.drawColor(Color.rgb(13,17,24));if(candles.size()<2){p.setColor(MUTED);p.setTextSize(18);c.drawText("Loading chart…",30,60,p);return;}
            double lo=Double.MAX_VALUE,hi=-Double.MAX_VALUE;for(Candle x:candles){lo=Math.min(lo,x.l);hi=Math.max(hi,x.h);}
            float w=getWidth(),h=getHeight(), gap=w/(float)candles.size(), range=(float)(hi-lo==0?1:hi-lo);
            for(int i=0;i<candles.size();i++){Candle x=candles.get(i);float xx=i*gap+gap/2;float yh=(float)((hi-x.h)/range*h*0.82f+10), yl=(float)((hi-x.l)/range*h*0.82f+10), yo=(float)((hi-x.o)/range*h*0.82f+10), yc=(float)((hi-x.c)/range*h*0.82f+10);
                boolean up=x.c>=x.o;p.setColor(up?GREEN:RED);c.drawLine(xx,yh,xx,yl,p);float top=Math.min(yo,yc),bot=Math.max(yo,yc);c.drawRect(xx-gap*.30f,top,xx+gap*.30f,Math.max(top+2,bot),p);}
            p.setColor(MUTED);p.setTextSize(10);c.drawText(String.format(Locale.US,"H %.6f",hi),8,18,p);c.drawText(String.format(Locale.US,"L %.6f",lo),8,h-8,p);
        }
    }

    class DTrade{String symbol,side;double entry,exit,pnl;DTrade(String s,String d,double e,double x,double q){symbol=s;side=d;entry=e;exit=x;pnl=q;}}
    class Demo{
        double cash=10000,pnl=0;int wins=0,losses=0;ArrayList<DTrade> trades=new ArrayList<>();Random r=new Random(7);
        int completed(){return trades.size();}
        double winRate(){return completed()==0?0:wins*100.0/completed();}
        double equity(HashMap<String,Double> p){return cash;}
        void execute(String s,String side,EditText input){
            double amt=100;try{amt=Double.parseDouble(input.getText().toString());}catch(Exception ignored){}
            double price=px.getOrDefault(s,0.0);if(price<=0||amt<=0){Toast.makeText(MainActivity.this,"Invalid amount/price",Toast.LENGTH_SHORT).show();return;}
            if(amt>cash){Toast.makeText(MainActivity.this,"Not enough demo USDT",Toast.LENGTH_SHORT).show();return;}
            double drift=price*(0.001+r.nextDouble()*0.004);boolean win=r.nextDouble()<0.62;
            double exit=side.equals("BUY")?(win?price+drift:price-drift):(win?price-drift:price+drift);
            double profit=(exit-price)*(amt/price)*(side.equals("BUY")?1:-1);cash+=profit;pnl+=profit;if(profit>=0)wins++;else losses++;
            trades.add(new DTrade(s,side,price,exit,profit));Toast.makeText(MainActivity.this,"Demo "+side+" filled",Toast.LENGTH_SHORT).show();
        }
        void reset(){cash=10000;pnl=0;wins=losses=0;trades.clear();}
    }
}
