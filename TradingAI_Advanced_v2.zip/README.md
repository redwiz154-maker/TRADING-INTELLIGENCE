# Trading AI Advanced Android v2

Native Android demo app with Home, Markets, Demo Trade, AI Analysis, History and Profile tabs.

The demo trade engine uses virtual USDT and records every simulated trade, P/L, wins, losses and win rate.

IMPORTANT: current AI signal engine is a deterministic demo heuristic with simulated price movement. It is NOT a validated investment model and must not be used as a claim of profitability.

Production roadmap:
- Binance public WebSocket candlesticks
- Forex/XAUUSD licensed feed
- multi-timeframe technical indicators
- order-flow/open-interest where legally available
- news/economic calendar
- secure read-only account connectors
- historical DB and walk-forward backtesting
- ML/LLM ensemble
- push notifications
- secure cloud backend

Never embed private exchange API secrets in the APK.
