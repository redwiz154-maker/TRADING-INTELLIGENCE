# Trading AI — Android prototype

This is a single-screen Android WebView app prototype that loads the bundled mobile dashboard.
It is SIGNAL-ONLY: it never places trades.

## Build
Open this project in Android Studio and build an APK.

## Next modules
- Binance candle/WebSocket engine
- XAUUSD/Forex feed
- Multi-timeframe indicators
- News/economic calendar
- Read-only user trade history
- Backtesting
- Push notifications
- Secure cloud AI engine

Never put Binance API secrets in the APK. Use a secure backend for private account data.
